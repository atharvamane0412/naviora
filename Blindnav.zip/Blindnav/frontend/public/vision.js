/* ============================================================
   BlindNav — Phase 2: Vision Module (YOLOv8n via ONNX Runtime Web)
   ============================================================
   Self-contained module. Include this AFTER app.js in index.html:

     <script src="https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/ort.min.js"></script>
     <script src="vision.js"></script>

   It hooks into the existing WebSocket (state.ws) and TTS (speak())
   from app.js, and exposes:
     - requestVisionCapture()  → call this on "what's ahead" command
     - VISION ready/loading state for UI feedback
   ============================================================ */

const VISION = {
  session: null,
  modelReady: false,
  modelLoading: false,
  inputSize: 640,
  // COCO class names (80 classes, standard YOLOv8 order)
  classNames: [
    'person','bicycle','car','motorcycle','airplane','bus','train','truck','boat',
    'traffic light','fire hydrant','stop sign','parking meter','bench','bird','cat',
    'dog','horse','sheep','cow','elephant','bear','zebra','giraffe','backpack',
    'umbrella','handbag','tie','suitcase','frisbee','skis','snowboard','sports ball',
    'kite','baseball bat','baseball glove','skateboard','surfboard','tennis racket',
    'bottle','wine glass','cup','fork','knife','spoon','bowl','banana','apple',
    'sandwich','orange','broccoli','carrot','hot dog','pizza','donut','cake','chair',
    'couch','potted plant','bed','dining table','toilet','tv','laptop','mouse',
    'remote','keyboard','cell phone','microwave','oven','toaster','sink',
    'refrigerator','book','clock','vase','scissors','teddy bear','hair drier',
    'toothbrush'
  ],
  // Classes especially relevant to a visually impaired pedestrian —
  // used only to prioritise announcement order, not to filter results
  priorityClasses: new Set([
    'person','car','bicycle','motorcycle','bus','truck','traffic light',
    'stop sign','bench','chair','dog','stairs','door'
  ]),
  confidenceThreshold: 0.45,
  iouThreshold: 0.45,
};

// ── Load the model (lazy — only on first capture request) ──
async function loadVisionModel() {
  if (VISION.modelReady || VISION.modelLoading) return;
  VISION.modelLoading = true;
  updateVisionStatus('Loading vision model…');

  try {
    // Model file should be hosted alongside the dashboard static files,
    // e.g. frontend/public/models/yolov8n.onnx
    // (Export instructions are in the README section of this module)
    VISION.session = await ort.InferenceSession.create('models/yolov8n.onnx', {
      executionProviders: ['webgl', 'wasm'],
      graphOptimizationLevel: 'all'
    });
    VISION.modelReady = true;
    log('🧠 Vision model loaded (YOLOv8n)', 'success');
    updateVisionStatus('Ready');
  } catch (err) {
    log('Vision model failed to load: ' + err.message, 'error');
    updateVisionStatus('Model unavailable');
  } finally {
    VISION.modelLoading = false;
  }
}

// ── Triggered by "what's ahead" voice command ──
async function requestVisionCapture() {
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
    showToast('Backend not connected', 'error');
    speak('Cannot reach the camera right now.');
    return;
  }

  showVisionPanel();
  updateVisionStatus('Requesting photo from camera…');
  speak('Checking what is ahead.');
  log('📷 Requesting camera capture…', 'info');

  // Load model in parallel with the capture request so we don't
  // waste the round-trip time waiting
  loadVisionModel();

  state.ws.send(JSON.stringify({ type: 'request_capture' }));

  // Safety timeout — if no frame arrives in 8s, tell the user
  clearTimeout(VISION._captureTimeout);
  VISION._captureTimeout = setTimeout(() => {
    updateVisionStatus('No response from camera');
    speak('The camera did not respond. It may be offline.');
  }, 8000);
}

// ── Handle incoming WS messages related to vision ──
// Call this from your existing handleWSMessage() switch statement:
//   case 'cam_frame_meta': handleCamFrameMeta(msg); break;
//   case 'cam_error':      handleCamError(msg); break;
//   case 'cam_status':     handleCamStatus(msg); break;
// Binary frames need a small addition to the ws.onmessage handler —
// see INTEGRATION NOTES at the bottom of this file.

let pendingCamMeta = null;

function handleCamFrameMeta(msg) {
  pendingCamMeta = { width: msg.width, height: msg.height, size: msg.size };
}

async function handleCamBinaryFrame(blobOrArrayBuffer) {
  clearTimeout(VISION._captureTimeout);
  updateVisionStatus('Frame received — analysing…');

  const blob = blobOrArrayBuffer instanceof Blob
    ? blobOrArrayBuffer
    : new Blob([blobOrArrayBuffer], { type: 'image/jpeg' });

  const imgURL = URL.createObjectURL(blob);
  const img = new Image();

  img.onload = async () => {
    drawVisionFrame(img);
    await runDetection(img);
    URL.revokeObjectURL(imgURL);
  };
  img.onerror = () => {
    updateVisionStatus('Failed to decode image');
    log('Vision: failed to decode captured frame', 'error');
  };
  img.src = imgURL;
}

function handleCamError(msg) {
  clearTimeout(VISION._captureTimeout);
  const reasons = {
    camera_offline: 'The camera is offline. Please check the ESP32-CAM is powered on.',
    capture_failed: 'The camera failed to capture a photo. Please try again.'
  };
  const text = reasons[msg.reason] || 'Something went wrong with the camera.';
  updateVisionStatus(text);
  speak(text);
  log('Vision error: ' + msg.reason, 'error');
}

function handleCamStatus(msg) {
  const badge = document.getElementById('cam-online-badge');
  if (!badge) return;
  badge.textContent = msg.online ? 'CAMERA ONLINE' : 'CAMERA OFFLINE';
  badge.className = 'cam-badge ' + (msg.online ? 'online' : 'offline');
}

// ── Canvas drawing ──
let visionCanvas, visionCtx;
function getVisionCanvas() {
  if (!visionCanvas) {
    visionCanvas = document.getElementById('vision-canvas');
    visionCtx = visionCanvas.getContext('2d');
  }
  return { canvas: visionCanvas, ctx: visionCtx };
}

function drawVisionFrame(img) {
  const { canvas, ctx } = getVisionCanvas();
  canvas.width = img.width;
  canvas.height = img.height;
  ctx.drawImage(img, 0, 0);
}

function drawBoundingBoxes(detections, imgW, imgH) {
  const { canvas, ctx } = getVisionCanvas();
  ctx.lineWidth = Math.max(2, imgW / 200);
  ctx.font = `${Math.max(14, imgW / 35)}px 'JetBrains Mono', monospace`;
  ctx.textBaseline = 'top';

  detections.forEach(d => {
    const color = VISION.priorityClasses.has(d.label) ? '#ff3b5c' : '#00d4ff';
    ctx.strokeStyle = color;
    ctx.strokeRect(d.x, d.y, d.w, d.h);

    const label = `${d.label} ${Math.round(d.confidence * 100)}%`;
    const textW = ctx.measureText(label).width + 8;
    ctx.fillStyle = color;
    ctx.fillRect(d.x, Math.max(0, d.y - 22), textW, 22);
    ctx.fillStyle = '#060810';
    ctx.fillText(label, d.x + 4, Math.max(0, d.y - 20));
  });
}

// ── Inference ──
async function runDetection(img) {
  if (!VISION.modelReady) {
    updateVisionStatus('Model still loading, please wait…');
    // Wait briefly for model to finish loading (max 5s)
    let waited = 0;
    while (!VISION.modelReady && waited < 5000) {
      await new Promise(r => setTimeout(r, 200));
      waited += 200;
    }
    if (!VISION.modelReady) {
      updateVisionStatus('Model unavailable');
      speak('Sorry, the vision model is not ready yet.');
      return;
    }
  }

  try {
    const inputTensor = preprocessImage(img);
    const feeds = { images: inputTensor };
    const results = await VISION.session.run(feeds);
    const output = results[Object.keys(results)[0]];

    const detections = postprocess(output, img.width, img.height);
    drawBoundingBoxes(detections, img.width, img.height);
    announceDetections(detections, img.width);
    updateVisionStatus(detections.length ? `${detections.length} object(s) found` : 'No objects detected');
  } catch (err) {
    console.error(err);
    updateVisionStatus('Detection failed');
    log('Vision inference error: ' + err.message, 'error');
  }
}

// Resize + normalise image into a [1,3,640,640] Float32 tensor (letterboxed)
function preprocessImage(img) {
  const size = VISION.inputSize;
  const off = document.createElement('canvas');
  off.width = size; off.height = size;
  const octx = off.getContext('2d');

  // Letterbox: scale to fit, pad with grey
  const scale = Math.min(size / img.width, size / img.height);
  const nw = img.width * scale, nh = img.height * scale;
  const dx = (size - nw) / 2, dy = (size - nh) / 2;

  octx.fillStyle = '#727272';
  octx.fillRect(0, 0, size, size);
  octx.drawImage(img, dx, dy, nw, nh);

  VISION._letterbox = { scale, dx, dy };

  const imageData = octx.getImageData(0, 0, size, size);
  const { data } = imageData;
  const float32Data = new Float32Array(3 * size * size);

  // HWC RGBA -> CHW RGB, normalised 0-1
  for (let i = 0; i < size * size; i++) {
    float32Data[i] = data[i * 4] / 255;                       // R
    float32Data[size * size + i] = data[i * 4 + 1] / 255;     // G
    float32Data[2 * size * size + i] = data[i * 4 + 2] / 255; // B
  }

  return new ort.Tensor('float32', float32Data, [1, 3, size, size]);
}

// Decode YOLOv8 output [1, 84, 8400] -> boxes in original image coords
function postprocess(output, origW, origH) {
  const data = output.data;
  const numBoxes = output.dims[2];   // 8400
  const numClasses = output.dims[1] - 4; // 80

  const candidates = [];
  for (let i = 0; i < numBoxes; i++) {
    let maxScore = 0, maxClass = -1;
    for (let c = 0; c < numClasses; c++) {
      const score = data[(4 + c) * numBoxes + i];
      if (score > maxScore) { maxScore = score; maxClass = c; }
    }
    if (maxScore < VISION.confidenceThreshold) continue;

    const cx = data[0 * numBoxes + i];
    const cy = data[1 * numBoxes + i];
    const w  = data[2 * numBoxes + i];
    const h  = data[3 * numBoxes + i];

    candidates.push({ cx, cy, w, h, score: maxScore, classId: maxClass });
  }

  const nmsResults = nms(candidates, VISION.iouThreshold);

  const { scale, dx, dy } = VISION._letterbox;
  return nmsResults.map(d => {
    // Undo letterbox transform back to original image pixel coords
    const x = (d.cx - d.w / 2 - dx) / scale;
    const y = (d.cy - d.h / 2 - dy) / scale;
    const w = d.w / scale;
    const h = d.h / scale;
    return {
      x: Math.max(0, x), y: Math.max(0, y),
      w: Math.min(w, origW - x), h: Math.min(h, origH - y),
      label: VISION.classNames[d.classId] || `class_${d.classId}`,
      confidence: d.score,
      centerXRatio: (x + w / 2) / origW
    };
  });
}

function nms(boxes, iouThresh) {
  boxes.sort((a, b) => b.score - a.score);
  const keep = [];
  const used = new Array(boxes.length).fill(false);

  for (let i = 0; i < boxes.length; i++) {
    if (used[i]) continue;
    keep.push(boxes[i]);
    for (let j = i + 1; j < boxes.length; j++) {
      if (used[j]) continue;
      if (iou(boxes[i], boxes[j]) > iouThresh) used[j] = true;
    }
  }
  return keep;
}

function iou(a, b) {
  const ax1 = a.cx - a.w / 2, ay1 = a.cy - a.h / 2, ax2 = a.cx + a.w / 2, ay2 = a.cy + a.h / 2;
  const bx1 = b.cx - b.w / 2, by1 = b.cy - b.h / 2, bx2 = b.cx + b.w / 2, by2 = b.cy + b.h / 2;
  const ix1 = Math.max(ax1, bx1), iy1 = Math.max(ay1, by1);
  const ix2 = Math.min(ax2, bx2), iy2 = Math.min(ay2, by2);
  const iw = Math.max(0, ix2 - ix1), ih = Math.max(0, iy2 - iy1);
  const interArea = iw * ih;
  const areaA = a.w * a.h, areaB = b.w * b.h;
  return interArea / (areaA + areaB - interArea);
}

// ── Position mapping + TTS announcement ──
function announceDetections(detections, imgWidth) {
  if (!detections.length) {
    speak('I don\'t see anything ahead.');
    return;
  }

  // Sort: priority safety classes first, then by confidence
  const sorted = [...detections].sort((a, b) => {
    const pa = VISION.priorityClasses.has(a.label) ? 1 : 0;
    const pb = VISION.priorityClasses.has(b.label) ? 1 : 0;
    if (pa !== pb) return pb - pa;
    return b.confidence - a.confidence;
  });

  // Limit to top 4 to keep announcement short
  const top = sorted.slice(0, 4);

  const phrases = top.map(d => {
    const pos = positionLabel(d.centerXRatio);
    return `a ${d.label} ${pos}`;
  });

  let sentence;
  if (phrases.length === 1) sentence = `I see ${phrases[0]}.`;
  else sentence = `I see ${phrases.slice(0, -1).join(', ')} and ${phrases[phrases.length - 1]}.`;

  speak(sentence);
  log(`👁️ Vision: ${top.map(d => `${d.label}(${Math.round(d.confidence*100)}%)`).join(', ')}`, 'success');
}

function positionLabel(centerXRatio) {
  if (centerXRatio < 0.33) return 'to the left';
  if (centerXRatio > 0.66) return 'to the right';
  return 'ahead';
}

// ── UI helpers ──
function showVisionPanel() {
  const panel = document.getElementById('vision-panel');
  if (panel) panel.style.display = 'block';
}

function updateVisionStatus(text) {
  const el = document.getElementById('vision-status');
  if (el) el.textContent = text;

  const scanLine = document.getElementById('vision-scan-line');
  if (scanLine) {
    const scanning = /requesting|analysing|loading/i.test(text);
    scanLine.classList.toggle('active', scanning);
  }
}

/* ============================================================
   INTEGRATION NOTES — apply these small edits to your existing
   app.js so this module is wired up correctly.
   ============================================================

   1) In handleWSMessage(msg), add three new cases:

        case 'cam_frame_meta': handleCamFrameMeta(msg); break;
        case 'cam_error':      handleCamError(msg);     break;
        case 'cam_status':     handleCamStatus(msg);    break;

   2) Your WebSocket currently only handles text frames
      (state.ws.onmessage parses e.data as JSON every time).
      Binary JPEG frames need their own branch. Replace your
      existing state.ws.onmessage handler with:

        state.ws.onmessage = (e) => {
          if (e.data instanceof Blob) {
            handleCamBinaryFrame(e.data);
            return;
          }
          try {
            const msg = JSON.parse(e.data);
            handleWSMessage(msg);
          } catch (err) { console.error('WS parse error', err); }
        };

   3) In handleVoiceAction(action, originalCmd), add a case for
      the new 'capture_vision' action returned by the backend's
      voice-command parser:

        case 'capture_vision':
          requestVisionCapture();
          break;

   4) Add this line to index.html, AFTER your existing app.js
      script tag, and BEFORE this file:

        <script src="https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/ort.min.js"></script>
        <script src="vision.js"></script>

   That's it — "What's ahead" / "What is in front" voice commands
   will now trigger a capture + detection + spoken announcement,
   and the vision panel will show the live photo with bounding
   boxes for a sighted helper to see.
   ============================================================ */
