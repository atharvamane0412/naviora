/* ============================================================
   BlindNav — Frontend Application Logic
   ============================================================ */

const CONFIG = {
  BACKEND_URL: window.location.hostname === 'localhost'
    ? 'http://localhost:3001'
    : 'https://blindnav-backend.onrender.com',
  WS_URL: window.location.hostname === 'localhost'
    ? 'ws://localhost:3001/dashboard'
    : 'wss://blindnav-backend.onrender.com/dashboard',
  OBSTACLE_THRESHOLD: 50,
  OFF_ROUTE_THRESHOLD: 30,
  GPS_TIMEOUT: 10000,
};

const state = {
  myLocation: null, destination: null, route: null, routeLayer: null,
  myMarker: null, destMarker: null, poiMarkers: [],
  isNavigating: false, isListening: false,
  ws: null, wsReconnectTimer: null, mapDark: true,
  offRouteAlertShown: false,
  speechSynth: window.speechSynthesis,
  recognition: null, currentStep: 0,
};

const map = L.map('map', { center: [18.5204, 73.8567], zoom: 15, zoomControl: false });
L.control.zoom({ position: 'bottomright' }).addTo(map);

const tileLayers = {
  dark:  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',  { attribution:'© OpenStreetMap © CARTO', maxZoom:20 }),
  light: L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', { attribution:'© OpenStreetMap © CARTO', maxZoom:20 })
};
tileLayers.dark.addTo(map);

const myIcon   = L.divIcon({ className:'', html:'<div class="my-location-marker"></div>', iconSize:[20,20], iconAnchor:[10,10] });
const destIcon = L.divIcon({ className:'', html:'<div class="destination-marker"></div>',  iconSize:[20,20], iconAnchor:[10,10] });
function poiIcon(emoji) { return L.divIcon({ className:'', html:`<div style="font-size:1.4rem;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.8))">${emoji}</div>`, iconSize:[28,28], iconAnchor:[14,14] }); }

// ── WebSocket ──
function connectWS() {
  if (state.ws && state.ws.readyState === WebSocket.OPEN) return;
  log('Connecting to device backend…', 'info');
  state.ws = new WebSocket(CONFIG.WS_URL);
  state.ws.onopen  = () => { log('Backend connected ✓', 'success'); updateWSStatus(true); clearTimeout(state.wsReconnectTimer); };
  state.ws.onmessage = (e) => { try { handleWSMessage(JSON.parse(e.data)); } catch(err){} };
  state.ws.onclose = () => { updateWSStatus(false); log('Backend disconnected. Reconnecting…','warn'); state.wsReconnectTimer = setTimeout(connectWS, 5000); };
  state.ws.onerror = () => log('WebSocket error','error');
}

function handleWSMessage(msg) {
  switch (msg.type) {
    case 'gps':      handleGPSUpdate(msg.data); break;
    case 'obstacle': handleObstacle(msg.detected, msg.distance, msg.sensors); break;
    case 'status':   handleDeviceStatus(msg.data); break;
  }
}

function updateWSStatus(connected) {
  document.getElementById('ws-dot').className   = 'pulse-dot' + (connected ? ' connected' : '');
  document.getElementById('ws-dot').style.background = connected ? 'var(--green)' : 'var(--warn)';
  document.getElementById('ws-label').textContent    = connected ? 'Backend Online' : 'Reconnecting…';
}

// ── GPS ──
function handleGPSUpdate(data) {
  const { lat, lng, speed, satellites, hdop } = data;
  if (!lat || !lng) return;
  state.myLocation = { lat, lng };

  if (!state.myMarker) state.myMarker = L.marker([lat,lng], { icon: myIcon }).addTo(map);
  else state.myMarker.setLatLng([lat, lng]);

  document.getElementById('gps-status').className  = 'status-pill active';
  document.getElementById('gps-label').textContent = 'GPS Fixed';
  document.getElementById('gps-dot').className     = 'pulse-dot connected';
  document.getElementById('coords-text').textContent = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;

  if (satellites !== undefined) {
    document.getElementById('sat-label').textContent = `${satellites} Sats`;
    document.getElementById('sat-val').textContent   = satellites;
    document.getElementById('sat-arc').style.strokeDashoffset = 163 - (163 * Math.min(satellites/12, 1));
  }
  if (speed !== undefined) {
    document.getElementById('spd-val').textContent = speed.toFixed(1);
    document.getElementById('spd-arc').style.strokeDashoffset = 163 - (163 * Math.min(speed/60, 1));
  }
  if (hdop !== undefined) {
    document.getElementById('hdop-val').textContent = hdop.toFixed(1);
    document.getElementById('hdop-arc').style.strokeDashoffset = 163 - (163 * Math.max(0, 1-(hdop/5)));
  }
  if (state.isNavigating && state.route) checkOffRoute(lat, lng);
  if (state.isNavigating) updateNavigationStep(lat, lng);
}

// ── 3-Sensor Radar ──
const radarState = {
  front: { detected: false, distance: null },
  left:  { detected: false, distance: null },
  right: { detected: false, distance: null }
};
let lastObstacleSpeakTime = 0;

function handleObstacle(detected, distance, sensors) {
  if (sensors) {
    radarState.front = sensors.front || { detected: false, distance: null };
    radarState.left  = sensors.left  || { detected: false, distance: null };
    radarState.right = sensors.right || { detected: false, distance: null };
  } else {
    // backward compat — single sensor treated as front
    radarState.front = { detected, distance };
    radarState.left  = { detected: false, distance: null };
    radarState.right = { detected: false, distance: null };
  }
  updateRadarZone('front', radarState.front);
  updateRadarZone('left',  radarState.left);
  updateRadarZone('right', radarState.right);
  updateRadarAlertStrip();
  updateBuzzerFromSensors();
  updateObstacleStatusPill();
  updateObstacleOverlay();
}

function updateRadarZone(dir, sensor) {
  const zone   = document.getElementById(`radar-${dir}`);
  const distEl = document.getElementById(`dist-${dir}`);
  const blip   = document.getElementById(`blip-${dir}`);
  if (!zone) return;

  const d = sensor.distance;
  distEl.textContent = (d !== null && d > 0) ? `${Math.round(d)} cm` : '—';
  zone.classList.remove('active-warn', 'active-danger');

  if (sensor.detected && d !== null) {
    zone.classList.add(d < 30 ? 'active-danger' : 'active-warn');
    if (blip) blip.style.display = 'block';
  } else {
    if (blip) blip.style.display = 'none';
  }
}

function updateRadarAlertStrip() {
  const strip  = document.getElementById('radar-alert-strip');
  const text   = document.getElementById('radar-alert-text');
  const alerts = Object.entries(radarState)
    .filter(([,s]) => s.detected && s.distance !== null)
    .map(([dir,s]) => ({ dir, d: s.distance }))
    .sort((a,b) => a.d - b.d);

  strip.classList.remove('warn', 'danger');

  if (!alerts.length) {
    text.textContent = 'All clear — no obstacles detected';
    return;
  }

  const isDanger = alerts[0].d < 30;
  strip.classList.add(isDanger ? 'danger' : 'warn');
  text.textContent = '⚠️ Obstacle — ' + alerts.map(a => `${Math.round(a.d)}cm ${a.dir}`).join('  |  ');

  const now = Date.now();
  if (now - lastObstacleSpeakTime > 4000) {
    lastObstacleSpeakTime = now;
    speak('Obstacle detected. ' + alerts.map(a => `${Math.round(a.d)} centimetres ${a.dir}`).join(', ') + '.');
  }
}

function updateBuzzerFromSensors() {
  const icon    = document.getElementById('buzzer-icon');
  const wave    = document.getElementById('buzzer-wave');
  const stateEl = document.getElementById('buzzer-state');
  const anyDanger   = Object.values(radarState).some(s => s.detected && s.distance !== null && s.distance < 30);
  const anyDetected = Object.values(radarState).some(s => s.detected);

  if (anyDanger) {
    icon.classList.add('active'); wave.classList.add('active');
    stateEl.textContent = 'DANGER!';
    if (navigator.vibrate) navigator.vibrate([200,80,200,80,200]);
  } else if (anyDetected) {
    icon.classList.add('active'); wave.classList.add('active');
    stateEl.textContent = Object.entries(radarState).filter(([,s])=>s.detected&&s.distance).map(([d,s])=>`${Math.round(s.distance)}cm ${d}`).join(' · ');
    if (navigator.vibrate) navigator.vibrate([200,100,200]);
  } else {
    icon.classList.remove('active'); wave.classList.remove('active');
    stateEl.textContent = 'Clear';
  }
}

function updateObstacleStatusPill() {
  const pill  = document.getElementById('obstacle-status');
  const label = document.getElementById('obstacle-label');
  const anyDanger   = Object.values(radarState).some(s => s.detected && s.distance !== null && s.distance < 30);
  const anyDetected = Object.values(radarState).some(s => s.detected);

  if (anyDanger) {
    pill.className = 'status-pill danger';
    label.textContent = 'DANGER: ' + Object.entries(radarState).filter(([,s])=>s.detected&&s.distance<30).map(([d])=>d).join(',');
  } else if (anyDetected) {
    pill.className = 'status-pill warn';
    label.textContent = 'Obstacle: ' + Object.entries(radarState).filter(([,s])=>s.detected).map(([d])=>d).join(',');
  } else {
    pill.className = 'status-pill';
    label.textContent = 'No Obstacle';
  }
}

function updateObstacleOverlay() {
  const overlay = document.getElementById('obstacle-overlay');
  const anyActive = Object.values(radarState).some(s => s.detected);
  if (anyActive) {
    overlay.style.display = 'flex';
    document.getElementById('obs-dist-text').textContent =
      Object.entries(radarState).filter(([,s])=>s.detected&&s.distance).map(([dir,s])=>`${Math.round(s.distance)}cm ${dir}`).join('  |  ');
    setTimeout(() => { overlay.style.display = 'none'; }, 3000);
  }
  const msgs = Object.entries(radarState).filter(([,s])=>s.detected).map(([d,s])=>`⚠️ ${d}: ${Math.round(s.distance)}cm`).join(' | ');
  if (msgs) log(msgs, 'error');
}

function handleDeviceStatus(data) {
  if (!data.gpsConnected) {
    document.getElementById('gps-label').textContent  = 'GPS Searching…';
    document.getElementById('gps-status').className   = 'status-pill warn';
    document.getElementById('buzzer-state').textContent = 'Scanning…';
    document.getElementById('buzzer-icon').classList.remove('active');
  }
}

// ── Voice ──
function initSpeechRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { log('Speech recognition not supported','warn'); document.getElementById('mic-btn').style.opacity='0.4'; return; }
  state.recognition = new SR();
  state.recognition.continuous = false; state.recognition.interimResults = true; state.recognition.lang = 'en-IN';
  state.recognition.onresult = (e) => {
    const t = Array.from(e.results).map(r=>r[0].transcript).join('');
    document.getElementById('transcript-text').textContent = t;
    if (e.results[e.results.length-1].isFinal) { processVoiceCommand(t); stopListening(); }
  };
  state.recognition.onerror = () => stopListening();
  state.recognition.onend   = () => { if (state.isListening) stopListening(); };
}

function startListening() {
  if (!state.recognition) return showToast('Voice recognition not available','warn');
  if (state.isListening) return;
  state.isListening = true;
  document.getElementById('mic-btn').classList.add('listening');
  document.getElementById('voice-visualizer').querySelector('.wave-bars').classList.add('active');
  document.getElementById('voice-hint').textContent = 'Listening…';
  document.getElementById('transcript-text').textContent = '';
  state.recognition.start();
  log('🎙️ Listening…','info');
}

function stopListening() {
  state.isListening = false;
  document.getElementById('mic-btn').classList.remove('listening');
  document.getElementById('voice-visualizer').querySelector('.wave-bars').classList.remove('active');
  document.getElementById('voice-hint').textContent = 'Tap mic or press Space';
  try { state.recognition.stop(); } catch(e) {}
}

async function processVoiceCommand(command) {
  log(`🎙️ "${command}"`, 'info');
  try {
    const res  = await fetch(`${CONFIG.BACKEND_URL}/api/voice-command`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ command, lat: state.myLocation?.lat, lng: state.myLocation?.lng }) });
    const data = await res.json();
    handleVoiceAction(data, command);
  } catch(err) { log('Voice processing failed','error'); }
}

function handleVoiceAction(action, originalCmd) {
  switch (action.action) {
    case 'show_location':
      if (state.myLocation) { map.flyTo([state.myLocation.lat, state.myLocation.lng], 17); speak('Showing your current location.'); }
      else speak('GPS not available yet.');
      break;
    case 'navigate':    speak(`Searching for ${action.destination}.`); searchAndNavigate(action.destination); break;
    case 'find_nearby': speak(`Finding nearest ${action.placeType}.`); findNearest(action.placeType); break;
    case 'stop_navigation': stopNavigation(); speak('Navigation stopped.'); break;
    case 'obstacle_info':
      const dirs = Object.entries(radarState).filter(([,s])=>s.detected&&s.distance).map(([d,s])=>`${Math.round(s.distance)}cm ${d}`);
      speak(dirs.length ? dirs.join(', ') : 'No obstacle detected.');
      break;
    default: speak(`Sorry, I didn't understand: ${originalCmd}`); log(`Unknown command: "${originalCmd}"`, 'warn');
  }
}

function simulateVoice(text) {
  document.getElementById('transcript-text').textContent = text.replace(/"/g,'');
  processVoiceCommand(text.replace(/"/g,''));
}

// ── Search & Navigation ──
async function handleSearch() {
  const q = document.getElementById('search-input').value.trim();
  if (!q) return;
  await searchAndNavigate(q);
}

async function searchAndNavigate(query) {
  log(`🔍 Searching: "${query}"`, 'info'); showToast(`Searching for ${query}…`); clearPOIMarkers();
  try {
    const params = new URLSearchParams({ q: query });
    if (state.myLocation) { params.append('lat', state.myLocation.lat); params.append('lng', state.myLocation.lng); }
    const res  = await fetch(`${CONFIG.BACKEND_URL}/api/search?${params}`);
    const data = await res.json();
    if (!data.results?.length) { showToast('No results found','warn'); speak(`No results found for ${query}.`); return; }
    showSearchResults(data.results);
    speak(`Found ${data.results.length} results. Tap a result to navigate.`);
  } catch(err) { log('Search failed: '+err.message,'error'); showToast('Search failed','error'); }
}

function showSearchResults(results) {
  const container = document.getElementById('search-results');
  container.innerHTML = ''; container.classList.add('open');
  const iconMap = { hospital:'🏥', pharmacy:'💊', fuel:'⛽', police:'🚔', restaurant:'🍽️', bank:'🏦', atm:'🏧', bus_stop:'🚌', school:'🏫', default:'📍' };
  results.forEach(place => {
    const icon = iconMap[place.type] || iconMap.default;
    const item = document.createElement('div');
    item.className = 'search-result-item';
    item.innerHTML = `<span class="result-icon">${icon}</span><div><div class="result-name">${place.name}</div><div class="result-addr">${place.fullName.split(',').slice(1,3).join(',')}</div></div>`;
    item.onclick = () => { setDestination(place.lat, place.lng, place.name); container.classList.remove('open'); document.getElementById('search-input').value=''; };
    container.appendChild(item);
    const marker = L.marker([place.lat, place.lng], { icon: poiIcon(icon) }).addTo(map).bindPopup(`<b>${place.name}</b>`);
    state.poiMarkers.push(marker);
  });
  if (results.length) {
    const bounds = L.latLngBounds(results.map(r=>[r.lat,r.lng]));
    if (state.myLocation) bounds.extend([state.myLocation.lat, state.myLocation.lng]);
    map.fitBounds(bounds, { padding:[40,40] });
  }
}

async function setDestination(lat, lng, name) {
  state.destination = { lat, lng, name };
  if (state.destMarker) map.removeLayer(state.destMarker);
  state.destMarker = L.marker([lat,lng], { icon: destIcon }).addTo(map).bindPopup(`<b>Destination:</b><br>${name}`).openPopup();
  document.getElementById('dest-name').textContent = name;
  document.getElementById('nav-panel').style.display = 'block';
  log(`📍 Destination set: ${name}`, 'success');
  speak(`Destination set to ${name}. Calculating route.`);
  await calculateRoute();
}

async function calculateRoute() {
  if (!state.myLocation || !state.destination) { showToast('Need GPS and destination','warn'); return; }
  const { lat: fLat, lng: fLng } = state.myLocation;
  const { lat: tLat, lng: tLng, name } = state.destination;
  try {
    const res  = await fetch(`${CONFIG.BACKEND_URL}/api/route?fromLat=${fLat}&fromLng=${fLng}&toLat=${tLat}&toLng=${tLng}`);
    const data = await res.json();
    if (data.error) { showToast('No route found','error'); return; }
    if (state.routeLayer) map.removeLayer(state.routeLayer);
    state.routeLayer = L.geoJSON(data.geometry, { style:{ color:'var(--accent,#00d4ff)', weight:4, opacity:0.85, lineCap:'round', lineJoin:'round' } }).addTo(map);
    state.route = data; state.isNavigating = true; state.currentStep = 0; state.offRouteAlertShown = false;
    const dist = (data.distance/1000).toFixed(2), mins = Math.round(data.duration/60);
    document.getElementById('nav-dist').textContent = `${dist} km`;
    document.getElementById('nav-time').textContent = `~${mins} min`;
    renderSteps(data.steps);
    map.fitBounds(state.routeLayer.getBounds(), { padding:[40,40] });
    log(`🗺️ Route to ${name}: ${dist}km (~${mins} min)`, 'success');
    speak(`Route calculated. ${dist} kilometres, approximately ${mins} minutes walking.`);
    showToast(`Route: ${dist}km | ~${mins} min`);
  } catch(err) { log('Route failed: '+err.message,'error'); showToast('Routing failed','error'); }
}

function renderSteps(steps) {
  const list = document.getElementById('steps-list'); list.innerHTML = '';
  const arrowMap = { 'turn-right':'→','turn-left':'←','turn-sharp-right':'↱','turn-sharp-left':'↰','straight':'↑','arrive':'🏁','depart':'🚶','roundabout':'🔄','merge':'↗' };
  steps.slice(0,8).forEach((step,i) => {
    const key = step.modifier ? `${step.instruction}-${step.modifier}` : step.instruction;
    const arrow = arrowMap[key] || arrowMap[step.instruction] || '↑';
    const dist = step.distance < 1000 ? `${Math.round(step.distance)}m` : `${(step.distance/1000).toFixed(1)}km`;
    const item = document.createElement('div'); item.className='step-item'; item.id=`step-${i}`;
    item.innerHTML = `<span class="step-arrow">${arrow}</span><span>${step.name||'Continue'} — ${dist}</span>`;
    list.appendChild(item);
  });
  if (steps.length) updateTurnInstruction(steps[0]);
}

function updateTurnInstruction(step) {
  if (!step) return;
  const arrowMap = {'turn-right':'→','turn-left':'←','straight':'↑','arrive':'🏁','depart':'🚶','roundabout':'🔄'};
  const key = step.modifier ? `${step.instruction}-${step.modifier}` : step.instruction;
  document.getElementById('turn-arrow').textContent = arrowMap[key] || '↑';
  document.getElementById('turn-text').textContent  = (step.name || 'Continue') + (step.distance ? ` — ${Math.round(step.distance)}m` : '');
}

function updateNavigationStep(lat, lng) {
  if (!state.route?.steps?.length) return;
  const step = state.route.steps[state.currentStep];
  if (!step?.location) return;
  const d = getDistance(lat, lng, step.location[1], step.location[0]);
  if (d < 15 && state.currentStep < state.route.steps.length-1) {
    state.currentStep++;
    const next = state.route.steps[state.currentStep];
    updateTurnInstruction(next);
    document.querySelectorAll('.step-item').forEach((el,i) => { el.style.color = i===state.currentStep ? 'var(--accent)' : ''; });
    if (next.instruction === 'arrive') { speak('You have arrived at your destination.'); showToast('You have arrived!','success'); }
    else speak(`In ${Math.round(next.distance)} metres, ${(next.modifier||next.instruction).replace('-',' ')}.`);
  }
}

function checkOffRoute(lat, lng) {
  if (!state.route?.geometry?.coordinates) return;
  let minDist = Infinity;
  for (const c of state.route.geometry.coordinates) { const d = getDistance(lat,lng,c[1],c[0]); if (d < minDist) minDist = d; }
  if (minDist > CONFIG.OFF_ROUTE_THRESHOLD && !state.offRouteAlertShown) {
    state.offRouteAlertShown = true;
    document.getElementById('alert-card').style.display = 'block';
    speak('Warning. You are off route. Recalculating.'); showToast('Off route!','warn');
    if (navigator.vibrate) navigator.vibrate([300,100,300,100,300]);
  } else if (minDist <= CONFIG.OFF_ROUTE_THRESHOLD) {
    state.offRouteAlertShown = false;
    document.getElementById('alert-card').style.display = 'none';
  }
}

async function recalculateRoute() {
  document.getElementById('alert-card').style.display = 'none';
  state.offRouteAlertShown = false;
  await calculateRoute();
}

function stopNavigation() {
  state.isNavigating = false; state.route = null; state.destination = null; state.currentStep = 0;
  if (state.routeLayer) { map.removeLayer(state.routeLayer); state.routeLayer = null; }
  if (state.destMarker) { map.removeLayer(state.destMarker); state.destMarker = null; }
  document.getElementById('nav-panel').style.display = 'none';
  document.getElementById('alert-card').style.display = 'none';
  clearPOIMarkers(); log('Navigation stopped','info'); speak('Navigation cancelled.'); showToast('Navigation stopped');
}

// ── Nearby ──
async function findNearest(type) {
  if (!state.myLocation) { showToast('GPS required','warn'); speak('GPS not available.'); return; }
  log(`🔍 Nearest ${type}…`,'info'); showToast(`Finding nearest ${type}…`); clearPOIMarkers();
  try {
    const res  = await fetch(`${CONFIG.BACKEND_URL}/api/nearby?lat=${state.myLocation.lat}&lng=${state.myLocation.lng}&type=${encodeURIComponent(type)}`);
    const data = await res.json();
    if (!data.results?.length) { showToast(`No ${type} found`,'warn'); speak(`No ${type} found nearby.`); return; }
    const emojiMap = {'petrol pump':'⛽','hospital':'🏥','pharmacy':'💊','police':'🚔','restaurant':'🍽️','bank':'🏦','atm':'🏧','bus stop':'🚌','school':'🏫'};
    const emoji = emojiMap[type] || '📍';
    data.results.forEach(p => { const m = L.marker([p.lat,p.lng],{icon:poiIcon(emoji)}).addTo(map).bindPopup(`<b>${p.name||type}</b>`); state.poiMarkers.push(m); });
    const nearest = data.results[0];
    speak(`Found ${data.results.length} ${type} nearby. Navigating to nearest: ${nearest.name||type}.`);
    log(`Found ${data.results.length} ${type}(s)`,'success');
    setDestination(nearest.lat, nearest.lng, nearest.name||type);
  } catch(err) { log('Nearby failed: '+err.message,'error'); showToast('Search failed','error'); }
}

// ── Utilities ──
function getDistance(lat1,lng1,lat2,lng2) {
  const R=6371000, dLat=(lat2-lat1)*Math.PI/180, dLng=(lng2-lng1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

function clearPOIMarkers() { state.poiMarkers.forEach(m=>map.removeLayer(m)); state.poiMarkers=[]; document.getElementById('search-results').classList.remove('open'); }
function centerOnMe() { if (state.myLocation) map.flyTo([state.myLocation.lat,state.myLocation.lng],17,{duration:1}); else showToast('GPS not available','warn'); }

function applyManualCoords() {
  const lat = parseFloat(document.getElementById('manual-lat').value);
  const lng = parseFloat(document.getElementById('manual-lng').value);
  if (isNaN(lat)||isNaN(lng)) { showToast('Invalid coordinates','error'); return; }
  handleGPSUpdate({ lat, lng, speed:0, satellites:4, hdop:1.5 });
  map.flyTo([lat,lng],16); log(`📍 Manual: ${lat.toFixed(5)}, ${lng.toFixed(5)}`,'info'); showToast('Manual location applied');
}

function toggleMapTheme() {
  state.mapDark = !state.mapDark;
  if (state.mapDark) { map.removeLayer(tileLayers.light); tileLayers.dark.addTo(map); document.getElementById('theme-btn').textContent='🌙'; }
  else { map.removeLayer(tileLayers.dark); tileLayers.light.addTo(map); document.getElementById('theme-btn').textContent='☀️'; }
}

function testSimulation() {
  const base={lat:18.5204,lng:73.8567}; let step=0;
  const sim = setInterval(()=>{
    handleGPSUpdate({ lat:base.lat+(Math.random()-0.5)*0.001, lng:base.lng+(Math.random()-0.5)*0.001, speed:3.2, satellites:8, hdop:1.2 });
    // also simulate random obstacles on 3 sensors
    handleObstacle(false, null, {
      front: { detected: Math.random()>0.7, distance: 40+Math.random()*80 },
      left:  { detected: Math.random()>0.8, distance: 30+Math.random()*60 },
      right: { detected: Math.random()>0.8, distance: 30+Math.random()*60 },
    });
    if (++step > 20) clearInterval(sim);
  }, 1500);
  showToast('GPS + Radar simulation started'); log('📡 Simulation running…','info');
}

function speak(text) {
  if (!state.speechSynth) return;
  state.speechSynth.cancel();
  const overlay = document.getElementById('tts-overlay');
  document.getElementById('tts-text').textContent = text;
  overlay.style.display = 'block';
  const utt = new SpeechSynthesisUtterance(text);
  utt.rate=0.9; utt.pitch=1; utt.volume=1;
  const voices = state.speechSynth.getVoices();
  const preferred = voices.find(v=>v.lang.startsWith('en')&&v.localService);
  if (preferred) utt.voice = preferred;
  utt.onend = () => { overlay.style.display='none'; };
  state.speechSynth.speak(utt);
}

function log(message, type='info') {
  if (!message) return;
  const list  = document.getElementById('log-list');
  const entry = document.createElement('div');
  entry.className = `log-entry log-${type}`;
  const now = new Date();
  const time = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}:${now.getSeconds().toString().padStart(2,'0')}`;
  entry.innerHTML = `<span class="log-time">${time}</span><span class="log-msg">${message}</span>`;
  list.prepend(entry);
  while (list.children.length > 60) list.removeChild(list.lastChild);
}

function clearLog() { document.getElementById('log-list').innerHTML=''; }

let toastTimer;
function showToast(message, type='') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast show' + (type ? ' '+type : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>{ toast.className='toast'; }, 3500);
}

// ── Events ──
document.getElementById('mic-btn').addEventListener('click', ()=>{ if(state.isListening) stopListening(); else startListening(); });
document.addEventListener('keydown', (e)=>{
  if (e.code==='Space'&&e.target.tagName!=='INPUT') { e.preventDefault(); if(state.isListening) stopListening(); else startListening(); }
  if (e.code==='Escape') { stopListening(); document.getElementById('search-results').classList.remove('open'); }
});
document.getElementById('search-input').addEventListener('keydown', e=>{ if(e.key==='Enter') handleSearch(); });
document.getElementById('search-input').addEventListener('input',   e=>{ if(!e.target.value) document.getElementById('search-results').classList.remove('open'); });
map.on('click',       ()=> document.getElementById('search-results').classList.remove('open'));
map.on('contextmenu', e => { const {lat,lng}=e.latlng; setDestination(lat,lng,`Custom Point (${lat.toFixed(4)}, ${lng.toFixed(4)})`); });

// ── Browser Geolocation fallback ──
function startBrowserGeolocation() {
  if (!navigator.geolocation) return;
  log('📡 Browser geolocation fallback','info');
  return navigator.geolocation.watchPosition(
    pos => handleGPSUpdate({ lat:pos.coords.latitude, lng:pos.coords.longitude, speed:pos.coords.speed?(pos.coords.speed*3.6):0, satellites:0, hdop:pos.coords.accuracy/10 }),
    err => log('Browser GPS error: '+err.message,'warn'),
    { enableHighAccuracy:true, maximumAge:5000, timeout:15000 }
  );
}

// ── Init ──
async function init() {
  log('🚀 BlindNav initializing…','info');
  initSpeechRecognition();
  connectWS();
  if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = ()=> log('🔊 TTS voices loaded','info');
  setTimeout(()=>{ if (!state.myLocation) startBrowserGeolocation(); }, CONFIG.GPS_TIMEOUT);
  log('✓ BlindNav ready. Say a command or tap 🎙️','success');
  setTimeout(()=> speak('BlindNav ready. Say a command or tap the microphone button.'), 1000);
}

init();